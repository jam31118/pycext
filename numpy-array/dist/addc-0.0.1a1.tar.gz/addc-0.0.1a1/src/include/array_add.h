int add_array_double(double *a, double *b, double *out, long N);
