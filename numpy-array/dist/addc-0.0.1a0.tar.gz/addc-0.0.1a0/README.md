# numpy C extension test

