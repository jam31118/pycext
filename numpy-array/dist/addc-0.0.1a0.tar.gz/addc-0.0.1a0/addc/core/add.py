def add_one(a): return a + 1
def add(a,b): return a + b

